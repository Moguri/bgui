bgui is a Python library to handle GUIs in the Blender Game Engine.

Author:
	Mitchell Stokes (Moguri); Email: mogurijin@gmail.com

Requirements:
	Fairly recent Blender 2.5 build

There currently isn't much in terms of documentation. I've tried to keep the
source well commented, and I've provided a simple demo in the examples folder.

Change Log:
	0.01: Initial "beta" release